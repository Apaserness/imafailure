package main

import (
	"fmt"
	"io/ioutil"
	"os"
)

func main() {
	a := os.Args[1:]
	var len int
	if len == 0 {
		fmt.Println("File name missing")
	} else if len > 1 {
		fmt.Println("Too many arguments")
	} else {
		file, err := ioutil.ReadFile(args[0])
		if err != nil {
			fmt.Println(err)
		}
		if ln == 1 {
			fmt.Print(string(file))
		}

	}

}
