package main

import "fmt"

func addTen(nbr int) int {
	return nbr + 10
}
func applyFunction(f func(int) int, answer int) int {
	answer = f(answer)
	return answer
}
func main() {
	result := 0
	arrayOfFunction := []func(int) int{addTen}

	result = applyFunction(arrayOfFunction[0], result)
	fmt.Println(result)
}
