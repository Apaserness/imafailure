package main

import (
	"fmt"
	"os"
)

func CheckRow(sudoku [9][9]int, row, k int) bool {
	for i := 0; i < 9; i++ {
		if sudoku[row][i] == k {
			return false
		}
	}
	return true
}

func CheckCol(sudoku [9][9]int, col, k int) bool {
	for i := 0; i < 9; i++ {
		if sudoku[i][col] == k {
			return false
		}
	}
	return true
}

func CheckBox(sudoku [9][9]int, row, col, k int) bool {
	starti := row - row%3
	startj := col - col%3
	for i := starti; i < starti+3; i++ {
		for j := startj; j < startj+3; j++ {
			if sudoku[i][j] == k {
				return false
			}
		}
	}
	return true
}

func SolveSudoku(sudoku *[9][9]int) bool {
	row := 0
	col := 0

	if IsDone(*sudoku, &row, &col) {
		return true
	}
	if sudoku[row][col] == 0 {
		for k := 1; k <= 9; k++ {
			if CheckRow(*sudoku, row, k) && CheckCol(*sudoku, col, k) && CheckBox(*sudoku, row, col, k) {
				(*sudoku)[row][col] = k
				//PrintSudoku(*sudoku)
				if SolveSudoku(sudoku) {
					return true
				}
				(*sudoku)[row][col] = 0
			}
		}
	}
	return false
}

func IsDone(sudoku [9][9]int, row, col *int) bool {
	for i := 0; i < 9; i++ {
		for j := 0; j < 9; j++ {
			if sudoku[i][j] == 0 {
				*row = i
				*col = j
				return false
			}
		}
	}
	return true
}

func GenerateArray(args []string) [9][9]int {
	var sudoku [9][9]int
	args = args[1:]
	for i := 0; i < len(args); i++ {
		runes := []rune(args[i])
		for j := 0; j < len(runes); j++ {
			if runes[j] >= '1' && runes[j] <= '9' {
				sudoku[i][j] = int(runes[j] - 48)
			} else if runes[j] == '.' {
				sudoku[i][j] = 0
			}
		}
	}
	return sudoku
}

func PrintSudoku(sudoku [9][9]int) {
	for i := 0; i < 9; i++ {
		for j := 0; j < 9; j++ {
			fmt.Printf("%v ", sudoku[i][j])
		}
		fmt.Println()
	}
	//fmt.Println()
}

func CheckArgs(args []string) bool {
	if len(args) != 10 {
		return false
	}
	for i, a := range args {
		if i != 0 {
			runes := []rune(a)
			if len(a) != 9 {
				return false
			}
			for _, r := range runes {
				if (r < '1' || r > '9') && r != '.' {
					return false
				}
			}
		}
	}
	return true
}

func main() {
	args := os.Args
	if !CheckArgs(args) {
		fmt.Println("Error")
	} else {
		sudoku := GenerateArray(args)
		if SolveSudoku(&sudoku) {
			PrintSudoku(sudoku)
		} else {
			fmt.Println("Error")
		}
	}
}
