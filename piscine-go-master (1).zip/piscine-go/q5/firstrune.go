package student

func FirstRune(s string) rune {
	s1 := []rune(s)
	return s1[0]
}
