package main

import (
	"github.com/01-edu/z01"
	"io/ioutil"
	"os"
)

func main() {

	a := os.Args[1:]
	var len int

	for c := range a {
		len = c + 1
	}
	if len == 0 {
		z01.PrintRune(ioutil.WriteFile())
	} else if len > 1 {
		z01.PrintRune("")
	} else {
		file, err := ioutil.ReadFile(a[0])
		if err != nil {
			z01.PrintRune(err)
		}

	}

}
