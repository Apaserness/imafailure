package student

func CollatzCountdown(start int) int {
	if start <= 0 {
		return -1
	}
	p := 1
	for start != 1 {
		if start%2 == 0 {
			start /= 2
			p++
		} else {
			start = 3*start + 1
			p++
		}

	}
	return p
}
