package piscine

func Compact(ptr *[]string) int {
	length := 0
	for _, c := range *ptr {
		if c != "" {
			length++
		}
	}
	ans := make([]string, length)
	cur := 0
	for _, c := range *ptr {
		if c != "" {
			ans[cur] = c
			cur++
		}
	}
	*ptr = ans
	return length

}
