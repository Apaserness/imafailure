package piscine

type student struct {
	Name     string
	Life     float32
	Age      int
	Aircraft int
}
