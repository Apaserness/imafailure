package piscine

func ActiveBits(n int) uint {
	var r uint
	for n > 0 {
		if n%2 == 1 {
			r++
		}
		n /= 2
	}

	return r
}
