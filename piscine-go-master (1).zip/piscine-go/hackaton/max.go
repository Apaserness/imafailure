package piscine

func Max(arr []int) int {
	length := 0
	for i := range arr {
		length = i + 1
	}
	for i := length; i > 0; i-- {
		for j := 1; j < i; j++ {
			if arr[j-1] > arr[j] {
				arr[j-1], arr[j] = arr[j], arr[j-1]
			}
		}
	}
	return arr[length-1]

}
