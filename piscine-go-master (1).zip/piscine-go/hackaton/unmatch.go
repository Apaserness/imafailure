package piscine

func Unmatch(arr []int) int {
	//length := 0
	for i := range arr {
		n := 04
		for j := range arr {
			if arr[j] == arr[i] && i != j {
				n++
			}
		}
		if n%2 == 0 {
			return arr[i]
		}
	}
	return -1

}
