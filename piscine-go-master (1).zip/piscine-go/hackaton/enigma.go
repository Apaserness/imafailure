package student

func Enigma(a ***int, b *int, c *******int, d ****int) {
	ac := *******c
	cd := ****d
	db := *b
	ba := ***a
	***a = db
	*b = cd
	*******c = ba
	****d = ac
}
