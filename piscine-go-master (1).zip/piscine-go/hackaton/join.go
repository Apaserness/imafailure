package piscine

func Join(strs []string, sep string) string {
	words := ""
	one := true
	for _, word := range strs {
		if one {
			words = word
			one = false
		} else {
			words += sep + word
		}
	}
	return words

}
