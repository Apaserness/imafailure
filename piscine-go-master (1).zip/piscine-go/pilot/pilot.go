package main

import "fmt"

type student struct {
	Name     string
	Life     float32
	Age      int
	Aircraft int
}

func main() {
	var donnie student
	donnie.Name = "Donnie"
	donnie.Life = 100.0
	donnie.Age = 24
	donnie.Aircraft = 1

	fmt.Println(donnie)
}