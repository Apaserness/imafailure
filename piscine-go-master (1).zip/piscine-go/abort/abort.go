package main

import "fmt"

func Abort(a, b, c, d, e int) int {
	groupin := []int{a, b, c, d, e}
	ln := 0
	for i := range groupin {
		ln = i + 1
	}
	for i := ln; i > 0; i-- {
		for j := 1; j < i; j++ {
			if groupin[j-1] > groupin[j] {
				groupin[j-1], groupin[j] = groupin[j], groupin[j-1]
			}
		}
	}
	return groupin[2]

}
func main() {
	middle := Abort(2, 3, 8, 5, 7)
	fmt.Println(middle)
}
