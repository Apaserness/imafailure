package main

import (
	"bufio"
	"fmt"
	"os"
)

func main() {

	read := bufio.NewReader(os.Stdin)
	length := 0
	var output []rune
	for {
		pattern, _, err := read.ReadRune()
		if err != nil {
			break
		}
		output = append(output, pattern)
		length++

	}
	if length > 0 {
		if output[0] != 'o' && output[0] != '/' && output[0] != 'A' { //if your input doesn look like o, /, A then write...
			fmt.Println("Not a Raid function")
			return
		}
		InputFunc(output)
	}
}
func TakeCoords(output []rune) (i, j int) {

	marker := true
	for _, pattern := range output {
		if pattern == '\n' {
			j++
			marker = false
		} else {
			if marker == true {
				i++
			}
		}
	}
	return i, j
}

func InputFunc(output []rune) {
	i, j := TakeCoords(output)
	f1 := ((i * j) + j - 1) - i
	f2 := ((i * j) + j - 2)
	if output[0] == 'o' { //determine raid
		fmt.Printf("[raid1a] [%d] [%d]", i, j)

	} else if output[0] == '/' {
		fmt.Printf("[raid1b] [%d] [%d]", i, j)

	} else if output[0] == 'A' {
		if i == 1 && j == 1 {
			fmt.Printf("[raid1c] [%d] [%d] || [raid1d] [%d] [%d] || [raid1e] [%d] [%d]", i, j, i, j, i, j) //why so many iii jjj
		} else if i == 1 && j > 0 && output[f1] == 'C' {
			fmt.Printf("[raid1c] [%d] [%d] || [raid1e] [%d] [%d]", i, j, i, j)
		} else if j == 1 && i > 0 && output[i-1] == 'C' {
			fmt.Printf("[raid1d] [%d] [%d] || [raid1e] [%d] [%d]", i, j, i, j)
		} else if output[f1] == 'C' && output[f2] == 'C' { //
			fmt.Printf("[raid1c] [%d] [%d]", i, j)
		} else if output[f1] == 'A' && output[f2] == 'C' { //
			fmt.Printf("[raid1d] [%d] [%d]", i, j)
		} else if output[f1] == 'C' && output[f2] == 'A' {
			fmt.Printf("[raid1e] [%d] [%d]", i, j)
		}
	}
	fmt.Println()
}
