package student

type NodeL struct {
	Data interface{}
	Next *NodeL
}

type List struct {
	Head *NodeL
	Tail *NodeL
}

func ListAt(l *NodeL, pos int) *NodeL {
	count := 0
	for l != nil {
		if count == pos {
			return l
		}
		l = l.Next
		count++
	}
	return nil
}
