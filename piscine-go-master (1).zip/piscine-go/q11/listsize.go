package student

type NodeL struct {
	Data interface{}
	Next *NodeL
}

type List struct {
	Head *NodeL
	Tail *NodeL
}

func ListSize(l *List) int {
	n := l.Head
	size := 0
	for n != nil {
		n = n.Next
		size++
	}
	return size
}
