package student

type NodeL struct {
	Data interface{}
	Next *NodeL
}

type List struct {
	Head *NodeL
	Tail *NodeL
}

func ListPushBack(l *List, data interface{}) {
	link := &NodeL{Data: data}

	if l.Head == nil {
		l.Head = link
		l.Tail = link
	} else {
		l.Tail.Next = link
		l.Tail = link
	}
}
