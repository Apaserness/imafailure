package student

type NodeL struct {
	Data interface{}
	Next *NodeL
}

type List struct {
	Head *NodeL
	Tail *NodeL
}

func ListLast(l *List) interface{} {
	if l == nil || l.Head == nil {
		return nil
	}
	cur := l.Head
	for {
		if cur.Next == nil {
			return cur.Data
		}
		cur = cur.Next
	}
}
