package main

import (
	"os"

	"github.com/01-edu/z01"
)

func printStr(str string) {
	arrayStr := []rune(str)
	len := 0

	for range arrayStr { //v
		len++
	}

	for i := 0; i < len; i++ {
		z01.PrintRune(arrayStr[i])
	}
	z01.PrintRune('\n')
}

func isEven(nbr int) bool {
	if nbr%2 == 0 {
		return true
	}
	return false
}

func main() {
	EvenMsg := "I have an even number of arguments"
	OddMsg := "I have an odd number of arguments"

	lenOfArg := -1

	for range os.Args {
		lenOfArg++
	}

	if isEven(lenOfArg) == true {
		printStr(EvenMsg)
	} else {
		printStr(OddMsg)
	}
}
