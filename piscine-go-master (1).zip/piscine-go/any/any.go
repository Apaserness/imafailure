package main

import "fmt"

func Any(f func(string) bool, arr []string) bool {
	for i := range arr {
		if f(arr[i]) == true {
			return true
		}
	}
	return false

}
func main() {
	tab1 := []string{"Hello", "how", "are", "you"}
	tab2 := []string{"This", "is", "4", "you"}

	result1 := Any(IsNumeric, tab1)
	result2 := Any(IsNumeric, tab2)

	fmt.Println(result1)
	fmt.Println(result2)
}
