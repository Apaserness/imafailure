package student

func Map(f func(int) bool, arr []int) []bool {
	len := 0
	for range arr {
		len++
	}

	answer := make([]bool, len)
	for i := range arr {
		answer[i] = f(arr[i])
	}
	return answer

}
