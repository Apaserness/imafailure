package student

func ForEach(f func(int), arr []int) {
	for _, each := range arr {
		f(each)
	}
}
