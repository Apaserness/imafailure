package student

func IsSorted(f func(a, b int) int, tab []int) bool {
	len := 0
	for range tab {
		len++
	}

	if len == 1 {
		return true
	}

	if f(tab[0], tab[1]) > 0 {
		for i := 0; i < len-1; i++ {
			if f(tab[i], tab[i+1]) < 0 {
				return false
			}
		}
	} else if f(tab[0], tab[1]) < 0 {
		for i := 0; i < len-1; i++ {
			if f(tab[i], tab[i+1]) > 0 {
				return false
			}
		}
	}
	return true
}
