package student

func UltimateDivMod(a *int, b *int) {
	var buffer int
	buffer = *a / *b
	*b = *a % *b
	*a = buffer
}
