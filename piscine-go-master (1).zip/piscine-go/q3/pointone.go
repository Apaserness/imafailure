package student

func PointOne(n *int) {
	*n = 1
}
