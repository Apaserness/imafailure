package student

func StrRev(s string) string {
	var a string
	for _, i := range s {
		a = string(i) + a
	}
	return a
}
