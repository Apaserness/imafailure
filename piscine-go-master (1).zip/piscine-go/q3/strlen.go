package student

func StrLen(str string) int {
	sum := 0
	for _, a := range str {
		if a == a {
			sum++
		}
	}
	return sum
}
