package main

import (
	"fmt"
	"os"
)

func main() {
	argu := os.Args[1:]
	w := []string{"galaxy", "01", "galaxy 01"}
	for _, arg := range argu {

		for _, l := range w {
			if arg == l {

				fmt.Println("Alert!!!")
				return
			}

		}
	}
}
