package main

import "github.com/01-edu/z01"

func PrintComb() {
  for i := '0'; i <= '9'; i++ {
    for k := '1'; k := '9'; k++ {
      for h := '2'; h := '9'; h++ {
        if i < k && k < h {
          z01.PrintRune(i)
          z01.PrintRune(k)
          z01.PrintRune(h)
          if i == '7' && k == '8' && h == '9' {
            z01.PrintRune(10)
            continue
          }
          z01.PrintRune(44)
          z01.PrintRune(32)
        }
      }
    }
  }
}